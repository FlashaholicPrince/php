<div class="top-links">
	<div class="links">
		<a href="index-1.php">Home</a>|
		<a href="#" onClick="showSearch();">Search</a>
	</div>
</div>